package com.example.notificationservices.controller;

import com.example.notificationservices.Model.NotificationRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.notificationservices.Service.EmailService;
import com.example.notificationservices.Model.NotificationRequest;
@RestController
@RequestMapping("/api/notifications")
public class NotificationController {
    private final EmailService emailService;

    @Autowired
    public NotificationController(EmailService emailService) {
        this.emailService = emailService;
    }

    @PostMapping("/send")
    public ResponseEntity<String> sendEmail(@RequestBody NotificationRequest request) {
        emailService.sendEmail(request.getTo(), request.getSubject(), request.getBody());
        return ResponseEntity.ok("Email sent successfully");
    }
}
