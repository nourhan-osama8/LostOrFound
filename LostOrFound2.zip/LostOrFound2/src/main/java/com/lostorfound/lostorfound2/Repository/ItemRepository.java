package com.lostorfound.lostorfound2.Repository;

import com.lostorfound.lostorfound2.Model.ItemModel;
import com.lostorfound.lostorfound2.Model.Status;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ItemRepository extends JpaRepository<ItemModel, Long> {
    List<ItemModel> findByCategoryIgnoreCase(String category);
    List<ItemModel> findByNameContainingIgnoreCase(String keyword);
    List<ItemModel> findByLocationContainingIgnoreCase(String location);
    List<ItemModel> findByStatus(Status statusEnum);
}