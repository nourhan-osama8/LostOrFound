package com.lostorfound.lostorfound2.Model;



public enum Status {
    LOST,
    FOUND,
    CLAIMED
}


