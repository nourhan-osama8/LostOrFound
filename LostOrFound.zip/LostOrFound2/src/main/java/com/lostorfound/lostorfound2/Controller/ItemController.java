package com.lostorfound.lostorfound2.Controller;


import com.lostorfound.lostorfound2.Model.ItemModel;
import com.lostorfound.lostorfound2.Model.Status;
import com.lostorfound.lostorfound2.Service.ItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/items")
public class ItemController {

    private final ItemService itemService;

    public ItemController(ItemService itemService) {
        this.itemService = itemService;
    }

    @GetMapping
    public List<ItemModel> getAllItems() {
        return itemService.getAllItems();
    }

    @PostMapping
    public void reportItem(@RequestBody ItemModel item) {
        itemService.reportItem(item);
    }
    @PostMapping("/report")
    public ItemModel reportLostItem(@RequestBody ItemModel item) {
        item.setStatus(Status.valueOf("LOST")); // Default to "LOST" when reported
        return itemService.addItem(item);
    }


    @DeleteMapping("/{id}")
    public boolean deleteItem(@PathVariable Long id) {
        return itemService.deleteItem(id);
    }

    @PutMapping("/{id}")
    public boolean updateItem(@PathVariable Long id, @RequestBody ItemModel updatedItem) {
        return itemService.updateItem(id, updatedItem);
    }

//    @GetMapping("/search")
//    public List<ItemModel> searchItems(@RequestParam String keyword) {
//        return itemService.searchItems(keyword);
//    }
//
//    @GetMapping("/status/{status}")
//    public List<ItemModel> getItemsByStatus(@PathVariable String status) {
//        return itemService.getItemsByStatus(status);
//    }
@GetMapping("/search/category")
public List<ItemModel> searchByCategory(@RequestParam String category) {
    return itemService.searchByCategory(category);
}

    @GetMapping("/search/keyword")
    public List<ItemModel> searchByKeyword(@RequestParam String keyword) {
        return itemService.searchByKeyword(keyword);
    }

    @GetMapping("/search/location")
    public List<ItemModel> searchByLocation(@RequestParam String location) {
        return itemService.searchByLocation(location);
    }
    @PutMapping("/claim/{id}")
    public boolean claimItem(@PathVariable Long id) {
        return itemService.claimItem(id);
    }


}

